/// Pusat konfigurasi URL
///
/// Semua URL API, WebSocket, dan tautan kontak diarahkan ke file ini,
/// jadi kalau server pindah cukup ganti di sini dan aplikasi ikut berubah.
class ApiConfig {
  // ===== Backend utama YOSHIMITSU =====
  static const String baseUrl = "http://raps-manipulator.jscloud.my.id:2045";

  // ===== WebSocket =====
  static const String wsUrl = "ws://raps-manipulator.jscloud.my.id:2045";

  // ===== Anime / Hentai (Sanka Vollerei) =====
  static const String animeBaseUrl = "https://www.sankavollerei.com/anime";
  static const String hentaiBaseUrl = "https://www.sankavollerei.com/anime/neko";

  // ===== API OSINT pihak ketiga =====
  static const String osintApiUrl = "https://api.siputzx.my.id";

  static const String osintPathNIK = "/api/tools/nik-checker";
  static const String osintPathDNS = "/api/tools/dns";
  static const String osintPathSubdomains = "/api/tools/subdomains";
  static const String osintPathInstagram = "/api/d/igdl";
  static const String osintPathTikTok = "/api/d/tiktok";
  static const String osintPathQR = "/api/tools/text2qr";

  // ===== NGL =====
  static const String nglBaseUrl = "https://ngl.link";
  static const String nglSubmitUrl = "https://ngl.link/api/submit";

  // ===== IP lookup =====
  static const String ipifyUrl = "https://api.ipify.org?format=json";
  static const String ipApiUrl = "http://ip-api.com/json";

  // ===== Kontak / Sosial Media =====
  static const String telegramChannel = "https://t.me/Fahri_Reals01";
  static const String telegramOwner = "https://t.me/Fahri_Reals01";
  static const String telegramInfo = "https://t.me/Fahri_Reals01";
  static const String whatsappOwner = "https://wa.me/62895406726553";
  static const String tiktokProfile =
      "https://www.tiktok.com/@painloggg?_r=1&_t=ZS-932NwfrWU5o";
  static const String instagramProfile =
      "https://www.instagram.com/darkness_reals?igsh=MWM2MDl5NXg0bTJpNg==";
}
